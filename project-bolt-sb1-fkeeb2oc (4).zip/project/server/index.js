import express from 'express';
import { corsMiddleware, securityMiddleware, errorHandler } from './middleware/index.js';
import routes from './routes.js';
import { config } from './config.js';

const app = express();

// Graceful shutdown handling
let server;
const shutdown = () => {
  console.log('Shutting down gracefully...');
  if (server) {
    server.close(() => {
      console.log('Server shutdown complete');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
};

// Handle shutdown signals
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Error handling for uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  shutdown();
});

// Middleware
app.use(corsMiddleware);
app.use(securityMiddleware);
app.use(express.json());

// Routes
app.use(routes);

// Error handling
app.use(errorHandler);

// Start server
const { port } = config.server;
server = app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});