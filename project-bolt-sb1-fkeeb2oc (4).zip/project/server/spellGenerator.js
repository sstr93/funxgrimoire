import { createCompletion } from './services/openai/index.js';
import { createSpellPrompt, createAdvicePrompt } from './prompts.js';

export async function generateSpell(theme, details) {
  try {
    const spell = await createCompletion(createSpellPrompt(theme, details), 'SPELL');
    return spell.trim();
  } catch (error) {
    console.error('Spell generation error:', error);
    throw error;
  }
}

export async function generateAdvice(theme, details) {
  try {
    const advice = await createCompletion(createAdvicePrompt(theme, details), 'ADVICE');
    return advice.trim();
  } catch (error) {
    console.error('Advice generation error:', error);
    throw error;
  }
}