export const OPENAI_CONSTANTS = {
  MODELS: {
    GPT4: 'gpt-4',
    GPT35: 'gpt-3.5-turbo'
  },
  MAX_RETRIES: 2,
  RETRY_DELAY: 1000,
  MAX_TOKENS: {
    SPELL: 2000,    // Increased for longer spell responses
    ADVICE: 1000    // Increased for longer advice responses
  }
};