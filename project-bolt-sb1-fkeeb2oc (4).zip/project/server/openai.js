import OpenAI from 'openai';
import { OPENAI_CONSTANTS } from './constants.js';
import { config } from './config.js';

const openai = new OpenAI({
  apiKey: config.openai.apiKey
});

export async function createCompletion(prompt, maxTokens = OPENAI_CONSTANTS.MAX_TOKENS.SPELL) {
  let attempts = 0;
  
  while (attempts <= OPENAI_CONSTANTS.MAX_RETRIES) {
    try {
      const response = await openai.chat.completions.create({
        model: OPENAI_CONSTANTS.MODELS.GPT4,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: maxTokens,
        temperature: 0.7,
      });
      return response.choices[0].message.content;
    } catch (error) {
      attempts++;
      if (attempts > OPENAI_CONSTANTS.MAX_RETRIES) {
        throw new Error(`OpenAI API Error: ${error.message}`);
      }
      if (error.status === 429) {
        await new Promise(resolve => setTimeout(resolve, OPENAI_CONSTANTS.RETRY_DELAY));
      }
    }
  }
}