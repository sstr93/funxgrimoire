import { Router } from 'express';
import { generateSpell, generateAdvice } from './spellGenerator.js';

const router = Router();

router.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

router.post('/api/generate-spell', async (req, res) => {
  try {
    const { theme, details } = req.body;
    if (!theme?.trim() || !details?.trim()) {
      return res.status(400).json({ error: 'Theme and details are required' });
    }
    const spell = await generateSpell(theme, details);
    res.json({ data: { spell }, status: 200 });
  } catch (error) {
    res.status(500).json({ error: error.message, status: 500 });
  }
});

router.post('/api/generate-advice', async (req, res) => {
  try {
    const { theme, details } = req.body;
    if (!theme?.trim() || !details?.trim()) {
      return res.status(400).json({ error: 'Theme and details are required' });
    }
    const advice = await generateAdvice(theme, details);
    res.json({ data: { advice }, status: 200 });
  } catch (error) {
    res.status(500).json({ error: error.message, status: 500 });
  }
});

export default router;