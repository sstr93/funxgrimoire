import helmet from 'helmet';

export const securityMiddleware = helmet({
  contentSecurityPolicy: false, // Disable CSP for development
  crossOriginEmbedderPolicy: false
});