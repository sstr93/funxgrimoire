export class OpenAIError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'OpenAIError';
    this.status = status;
  }
}

export class RateLimitError extends OpenAIError {
  constructor() {
    super('Rate limit exceeded. Please try again later.', 429);
    this.name = 'RateLimitError';
  }
}