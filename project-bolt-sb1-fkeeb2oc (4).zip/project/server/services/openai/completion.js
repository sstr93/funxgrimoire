import { openai } from './client.js';
import { OpenAIError, RateLimitError } from './errors.js';
import { OPENAI_CONSTANTS } from '../../constants.js';

export async function createCompletion(prompt, type = 'SPELL') {
  let attempts = 0;
  
  while (attempts <= OPENAI_CONSTANTS.MAX_RETRIES) {
    try {
      const response = await openai.chat.completions.create({
        model: 'gpt-4',  // Using GPT-4 for better quality responses
        messages: [{ 
          role: 'user', 
          content: prompt 
        }],
        temperature: 0.7,
        max_tokens: OPENAI_CONSTANTS.MAX_TOKENS[type],
        presence_penalty: 0.1,
        frequency_penalty: 0.1,
        stream: false
      });
      
      const content = response.choices[0].message.content;
      return content; // Remove truncation to get full response
    } catch (error) {
      attempts++;
      if (error.status === 429) {
        if (attempts > OPENAI_CONSTANTS.MAX_RETRIES) throw new RateLimitError();
        await new Promise(resolve => setTimeout(resolve, OPENAI_CONSTANTS.RETRY_DELAY));
        continue;
      }
      throw new OpenAIError(error.message || 'Failed to generate completion', error.status || 500);
    }
  }
}