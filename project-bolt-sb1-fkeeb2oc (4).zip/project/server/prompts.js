export const createSpellPrompt = (theme, details) => `
Create a dark-themed magical spell for ${theme} using only common household items. Context: ${details}

Format the response with clear sections and line breaks as follows:

🔮 [GENERATE A DRAMATIC SPELL NAME BASED ON THE INTENTION]

Items Required:
1. [Common household item]
2. [Common household item]
3. [Common household item]
4. [Optional common item]

Ritual Steps:
1. [First simple step using the items]

2. [Second simple step]

3. [Final step]

Incantation:
[A short, dramatic phrase]

Note: Keep items practical and easily found at home or in nature. No rare or expensive items.
`.trim();

export const createAdvicePrompt = (theme, details) => `
Provide 3 practical, real-world steps for ${theme}. Context: ${details}

Format as 3 clear, actionable bullet points that anyone can follow today. Focus on immediate actions, not long-term or vague suggestions. Keep it grounded in reality without any mystical elements.

Example format:
• [Immediate action step]
• [Practical step]
• [Simple action step]

Keep it brief and actionable.
`.trim();