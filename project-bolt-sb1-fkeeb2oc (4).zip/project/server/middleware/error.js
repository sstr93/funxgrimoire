export const errorHandler = (err, req, res, next) => {
  console.error('Server error:', err);
  
  // Handle specific error types
  if (err.name === 'OpenAIError') {
    return res.status(err.status || 500).json({
      error: err.message,
      status: err.status || 500
    });
  }

  // Default error response
  const status = err.status || 500;
  const message = process.env.NODE_ENV === 'production' 
    ? 'Internal server error' 
    : err.message || 'Internal server error';
  
  res.status(status).json({
    error: message,
    status
  });
};