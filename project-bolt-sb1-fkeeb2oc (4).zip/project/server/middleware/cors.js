import cors from 'cors';
import { config } from '../config.js';

export const corsMiddleware = cors({
  origin: (origin, callback) => {
    if (!origin || config.cors.origin.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: config.cors.credentials,
  methods: config.cors.methods,
  allowedHeaders: config.cors.allowedHeaders,
  optionsSuccessStatus: 200
});