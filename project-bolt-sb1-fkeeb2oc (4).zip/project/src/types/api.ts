import type { SpellResult } from './spell';

export interface APIErrorResponse {
  error: string;
  status?: number;
}

export interface APISuccessResponse<T> {
  data: T;
  status: number;
}

export type APIResponse<T> = APISuccessResponse<T> | APIErrorResponse;

export interface SpellGenerateRequest {
  theme: string;
  details: string;
}