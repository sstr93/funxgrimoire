import type { SpellTheme } from '../constants/spellThemes';

export interface SpellFormProps {
  onSubmit: (theme: string, details: string) => void;
  isLoading: boolean;
}

export interface SpellResult {
  spell: string;
  advice: string;
}