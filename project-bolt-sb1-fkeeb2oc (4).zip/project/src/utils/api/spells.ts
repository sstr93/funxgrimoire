import { API_CONFIG } from './config';
import { APIError } from './errors';
import type { SpellResult } from '../../types/spell';

export async function generateSpell(theme: string, details: string): Promise<SpellResult> {
  try {
    const response = await fetch(API_CONFIG.endpoints.generateSpell, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ theme, details })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Server error' }));
      throw new APIError(errorData.error || `Request failed with status ${response.status}`);
    }

    const data = await response.json();
    
    // Handle both direct response and nested data structure
    const result = data.data || data;
    
    if (!result.spell || !result.advice) {
      throw new APIError('Invalid response format from server');
    }

    return {
      spell: result.spell,
      advice: result.advice
    };
  } catch (error) {
    console.error('API Error:', error);
    if (error instanceof APIError) {
      throw error;
    }
    throw new APIError('Failed to generate spell. Please try again later.');
  }
}