export const API_CONFIG = {
  // Update this to your actual backend server URL
  baseUrl: import.meta.env.PROD ? 'https://your-backend-server.com' : '',
  endpoints: {
    health: '/health',
    generateSpell: '/api/generate-spell',
    generateAdvice: '/api/generate-advice'
  }
};