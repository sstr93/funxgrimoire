import { API_CONFIG } from './config';
import type { HealthCheckResponse } from './types';

export async function checkServerHealth(): Promise<boolean> {
  try {
    const response = await fetch(`${API_CONFIG.baseUrl}${API_CONFIG.endpoints.health}`);
    const data = await response.json() as HealthCheckResponse;
    return data.status === 'ok';
  } catch {
    return false;
  }
}