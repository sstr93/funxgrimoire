export interface APIResponse<T> {
  data?: T;
  error?: string;
  status: number;
}

export interface HealthCheckResponse {
  status: 'ok' | 'error';
}