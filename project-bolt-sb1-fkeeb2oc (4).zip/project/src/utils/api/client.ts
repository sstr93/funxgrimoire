import { API_CONFIG } from './config';
import { APIError } from './errors';
import type { APIResponse } from '../../types/api';

export async function apiClient<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  try {
    const response = await fetch(`${API_CONFIG.baseUrl}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new APIError(`HTTP error ${response.status}`, response.status);
    }

    const data = await response.json() as APIResponse<T>;

    if ('error' in data) {
      throw new APIError(data.error, data.status);
    }

    return data.data;
  } catch (error) {
    if (error instanceof APIError) {
      throw error;
    }
    throw new APIError(
      error instanceof Error ? error.message : 'Network error occurred'
    );
  }
}