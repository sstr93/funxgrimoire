import { useState } from 'react';
import SpellForm from './components/SpellForm';
import SpellResult from './components/SpellResult';
import { generateSpell } from './utils/api';
import type { SpellResult as SpellResultType } from './types/spell';

export default function App() {
  const [spellResult, setSpellResult] = useState<SpellResultType | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSpellGeneration = async (theme: string, details: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await generateSpell(theme, details);
      setSpellResult(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
      console.error('Error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-pattern text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <header className="text-center mb-12 glass-effect p-8 rounded-lg">
            <h1 className="text-5xl font-bold mb-4 text-red-500">
              FunxArts Grimoire
            </h1>
            <p className="text-xl text-gray-200">Your Source of Mystical Wisdom</p>
          </header>

          <SpellForm onSubmit={handleSpellGeneration} isLoading={isLoading} />
          
          {error && (
            <div className="mt-4 p-4 glass-effect rounded-lg text-red-400">
              {error}
            </div>
          )}
          {spellResult && <SpellResult result={spellResult} />}

          <footer className="mt-16 text-center text-sm glass-effect p-4 rounded-lg">
            <p className="text-gray-200">Created with the wisdom and energy of the FunxArts community</p>
            <p className="text-gray-400 mt-1">For entertainment only</p>
          </footer>
        </div>
      </div>
    </div>
  );
}