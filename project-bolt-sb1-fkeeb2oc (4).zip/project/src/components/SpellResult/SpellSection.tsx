import React from 'react';
import { Sparkles } from 'lucide-react';

interface SpellSectionProps {
  spell: string;
}

export const SpellSection: React.FC<SpellSectionProps> = ({ spell }) => (
  <div className="glass-effect p-6 rounded-lg shadow-xl mt-6 border border-red-900/30">
    <h2 className="font-display text-2xl mb-6 flex items-center gap-2 text-red-400">
      <Sparkles className="text-red-500" />
      Dark Ritual
    </h2>
    <div className="space-y-4">
      <p className="font-body text-lg whitespace-pre-line text-red-100/90 leading-relaxed">
        {spell}
      </p>
    </div>
  </div>
);