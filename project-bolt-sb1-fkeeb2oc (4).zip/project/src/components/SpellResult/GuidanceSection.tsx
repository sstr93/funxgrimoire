import React from 'react';
import { Lightbulb } from 'lucide-react';

interface GuidanceSectionProps {
  advice: string;
}

export const GuidanceSection: React.FC<GuidanceSectionProps> = ({ advice }) => (
  <div className="glass-effect p-6 rounded-lg shadow-xl mt-6 border border-red-900/30">
    <h2 className="font-display text-2xl mb-6 flex items-center gap-2 text-red-400">
      <Lightbulb className="text-red-500" />
      Mystical Guidance
    </h2>
    <p className="font-body text-lg text-red-100/90 whitespace-pre-line leading-relaxed">
      {advice}
    </p>
  </div>
);