import React from 'react';
import type { SpellResult as SpellResultType } from '../../types/spell';
import { SpellSection } from './SpellSection';
import { GuidanceSection } from './GuidanceSection';

interface SpellResultProps {
  result: SpellResultType;
}

const SpellResult: React.FC<SpellResultProps> = ({ result }) => {
  if (!result?.spell || !result?.advice) return null;

  return (
    <div className="space-y-6">
      <SpellSection spell={result.spell} />
      <GuidanceSection advice={result.advice} />
    </div>
  );
};

export default SpellResult;