import React, { useState } from 'react';
import { SPELL_THEMES } from '../constants/spellThemes';
import { LoadingMessage } from './LoadingMessage';
import type { SpellFormProps } from '../types/spell';

export default function SpellForm({ onSubmit, isLoading }: SpellFormProps) {
  const [theme, setTheme] = useState('');
  const [details, setDetails] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (theme && details) {
      onSubmit(theme, details);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="glass-effect p-6 rounded-lg shadow-xl">
      <div className="mb-4">
        <label htmlFor="theme" className="font-display block text-lg font-bold mb-3 text-red-400">
          Choose Your Theme
        </label>
        <select
          id="theme"
          value={theme}
          onChange={(e) => setTheme(e.target.value)}
          className="w-full px-4 py-2 rounded bg-black/50 border border-red-900/50 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
          required
          disabled={isLoading}
        >
          <option value="">Select a theme...</option>
          {SPELL_THEMES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      <div className="mb-6">
        <label htmlFor="details" className="font-display block text-lg font-bold mb-3 text-red-400">
          Your Intention
        </label>
        <textarea
          id="details"
          value={details}
          onChange={(e) => setDetails(e.target.value)}
          className="w-full px-4 py-2 rounded bg-black/50 border border-red-900/50 text-white focus:outline-none focus:ring-2 focus:ring-red-500 h-32"
          placeholder="Share what you wish to manifest..."
          required
          disabled={isLoading}
        />
      </div>

      <button
        type="submit"
        className="w-full bg-gradient-to-r from-red-800 to-red-600 hover:from-red-700 hover:to-red-500 text-white font-bold py-3 px-4 rounded flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
        disabled={isLoading}
      >
        {isLoading ? (
          <div className="flex items-center gap-2">
            <LoadingMessage />
          </div>
        ) : (
          'Retrieve My Spell'
        )}
      </button>
    </form>
  );
}