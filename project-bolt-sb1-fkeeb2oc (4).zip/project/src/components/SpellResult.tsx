import React from 'react';
import { Scroll, Lightbulb } from 'lucide-react';
import type { SpellResult as SpellResultType } from '../types/spell';

interface SpellResultProps {
  result: SpellResultType;
}

const SpellResult: React.FC<SpellResultProps> = ({ result }) => {
  if (!result?.spell || !result?.advice) return null;

  return (
    <div className="mt-8 space-y-6">
      <div className="glass-effect p-6 rounded-lg shadow-xl border border-red-900/30">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-red-400">
          <Scroll className="text-red-500" />
          Your Mystical Spell
        </h2>
        <div className="prose">
          <p className="whitespace-pre-line text-red-100/90">{result.spell}</p>
        </div>
      </div>

      <div className="glass-effect p-6 rounded-lg shadow-xl border border-red-900/30">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-red-400">
          <Lightbulb className="text-red-500" />
          Practical Guidance
        </h2>
        <p className="text-red-100/90 whitespace-pre-line">{result.advice}</p>
      </div>
    </div>
  );
};

export default SpellResult;