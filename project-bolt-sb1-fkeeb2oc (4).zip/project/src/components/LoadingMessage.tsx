import React, { useState, useEffect } from 'react';
import { LOADING_MESSAGES } from '../constants/loadingMessages';

export const LoadingMessage: React.FC = () => {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((current) => 
        current === LOADING_MESSAGES.length - 1 ? 0 : current + 1
      );
    }, 3500);

    return () => clearInterval(interval);
  }, []);

  return (
    <span className="text-white font-semibold">
      {LOADING_MESSAGES[messageIndex]}
    </span>
  );
};