export const SPELL_THEMES = [
  'Abundance & Prosperity',
  'Love & Relationships',
  'Health & Vitality',
  'Protection & Safety',
  'Wisdom & Knowledge',
  'Career & Success',
  'Creativity & Inspiration',
  'Peace & Harmony'
] as const;

export type SpellTheme = typeof SPELL_THEMES[number];