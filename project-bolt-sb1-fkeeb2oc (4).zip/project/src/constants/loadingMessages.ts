export const LOADING_MESSAGES = [
  "Entering mystical state...",
  "Communicating with the void...",
  "Unlocking ancient knowledge...",
  "Researching old grimoires..."
] as const;