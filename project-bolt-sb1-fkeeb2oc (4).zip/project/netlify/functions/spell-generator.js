import OpenAI from 'openai';
import { createSpellPrompt, createAdvicePrompt } from '../../server/prompts.js';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

async function generateCompletion(prompt, maxTokens = 2000) {
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: maxTokens,
      temperature: 0.7,
    });
    return response.choices[0].message.content;
  } catch (error) {
    console.error('OpenAI API Error:', error);
    throw new Error('Failed to generate completion');
  }
}

export async function handler(event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { theme, details } = JSON.parse(event.body);
    
    if (!theme?.trim() || !details?.trim()) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Theme and details are required' })
      };
    }

    const [spell, advice] = await Promise.all([
      generateCompletion(createSpellPrompt(theme, details)),
      generateCompletion(createAdvicePrompt(theme, details), 1000)
    ]);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        data: { spell, advice }
      })
    };
  } catch (error) {
    console.error('Function error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: 'Failed to generate spell. Please try again later.'
      })
    };
  }
}